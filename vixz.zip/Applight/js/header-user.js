const header = document.querySelector('#header')

header.innerHTML += `	<section class="banner mb-5">
<nav class="navbar navbar-expand-lg">
</nav>
<div class="d-flex container justify-content-between">
    <a class="navbar-brand navbar-logo logo" href="./index.html"> <img src="vixz.png" alt="logo" class="logo-1"> </a>
    <a class="navbar-brand navbar-logo d-flex flex-column user align-items-center perfil" href="./perfil.html">
        <i class="bi bi-person-circle" style="font-size: 50px; color: white;"></i>
        <p style="color: white; font-weight: bold;">Perfil</p>
    </a>
</div>
</section>`

