# Não enviar o node_modules no SIGAA

# 1- Comunicar o Front (Fetch) com o Back (Api Express)
> Usar o "Fetch" no front e "Api Express" no Back

# Raw (Json) - Postman
    {
        "mensagem": "oi"
    }
 
